﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var13_2
{
    public class SparseMatrix
    {
        private Coefficient[] coefficients;
        private int size;

        public SparseMatrix(int size, Coefficient[] coeffs)
        {
            this.size = size;
            this.coefficients = new Coefficient[size];
            for (int i = 0; i < size; i++)
            {
                this.coefficients[i] = coeffs[i];
            }
        }

        public SparseMatrix(SparseMatrix other)
        {
            this.size = other.size;
            this.coefficients = new Coefficient[size];
            Array.Copy(other.coefficients, this.coefficients, size);
        }

        public void ChangeCoefficient(int index, int newRow, int newColumn, double newValue)
        {
            if (index >= 0 && index < size)
            {
                coefficients[index].Row = newRow;
                coefficients[index].Column = newColumn;
                coefficients[index].Value = newValue;
            }
            else
            {
                Console.WriteLine("Index out of range.");
            }
        }

        public void PrintMatrix()
        {
            for (int i = 0; i < size; i++)
            {
                Console.WriteLine($"Row: {coefficients[i].Row}, Column: {coefficients[i].Column}, Value: {coefficients[i].Value}");
            }
        }
    }
}
