import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Завантаження даних з файлу
data = pd.read_csv("C:\\Users\\User\\Desktop\\KR Pyton\\MyTestTex.txt", delimiter=';', encoding='cp1251')

# Перетворення стовбця 'Дата' в об'єкт типу дати
data['Дата'] = pd.to_datetime(data['Дата'], format='%m-%Y')

# Побудова графіка за допомогою seaborn
plt.figure(figsize=(10, 6))
sns.lineplot(data=data, x='Дата', y='Покупка', hue='Валюта', palette='tab10', linewidth=2.5)
plt.title('Курси валют')
plt.xlabel('Дата')
plt.ylabel('Курс покупки')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
