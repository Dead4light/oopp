import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

valuta = 'USD'

df = pd.read_csv("C:\\Users\\User\\Desktop\\KR Pyton\\MyTestTex.txt", delimiter=';', encoding='cp1251')

valuta_data = df[df['Валюта'] == valuta]

valuta_data['Рік'] = valuta_data['Дата'].apply(lambda x: int(x.split('-')[0]))

valuta_data['Покупка'] = valuta_data['Покупка'].str.replace(',', '.').astype(float)
valuta_data['Продажа'] = valuta_data['Продажа'].str.replace(',', '.').astype(float)

# Побудова графіка
sns.set_theme(style="whitegrid")
plt.figure(figsize=(10, 6))
sns.pointplot(data=valuta_data, x='Рік', y='Покупка', color='blue', label='Середня покупка')
sns.pointplot(data=valuta_data, x='Рік', y='Продажа', color='orange', label='Середня продажа')
plt.xlabel('Рік')
plt.ylabel('Ціна за рік в грн')
plt.title(f'Середня ціна {valuta} за рік')
plt.legend()
plt.show()
