import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


df = pd.read_csv("C:\\Users\\User\\Desktop\\KR Pyton\\MyTestTex.txt", delimiter=';', encoding='cp1251')
df_USD = df[df['Валюта'] == 'USD']
'''   Валюта Покупка Продажа     Дата  Unnamed: 4
0     USD   24,40   24,70  03-2020         NaN
5     USD   26,72   26,95  06-2020         NaN
10    USD   27,45   27,65  09-2020         NaN
15    USD   28,40   28,60  12-2020         NaN
20    USD   27,85   28,05  03-2021         NaN
25    USD   26,86   27,05  09-2021         NaN
30    USD   27,12   27,33  12-2021         NaN
35    USD   29,25   29,70  03-2022         NaN
40    USD   35,00   36,00  06-2022         NaN
45    USD   40,00   40,70  09-2022         NaN
50    USD   27,35   27,55  06-2021         NaN
55    USD   39,90   40,40  12-2022         NaN
60    USD   38,50   39,30  03-2023         NaN
65    USD   37,15   37,50  06-2023         NaN
70    USD   37,50   38,20  09-2023         NaN
75    USD   37,05   37,55  12-2023         NaN'''
# Загальний графік продажі 3м






