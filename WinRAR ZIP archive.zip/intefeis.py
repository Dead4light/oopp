from tkinter import *
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

def Checker():
    print("Nihao")



def Button_USD():
    valuta = 'USD'
    Checker()
def Button_EUR():
    valuta = 'EUR'
    Checker()
def Button_PLN():
    valuta = 'PLN'
    Checker()
def Button_GBP():
    valuta = 'GBP'
    Checker()
def Button_CHF():
    valuta = 'CHF'
    Checker()

valuta = 'CHF'

root = Tk()
root.configure(bg="lightgrey")
var = IntVar()
var.set(1)

frame1 = Frame(root)
label1 = Label(frame1, text="Оберіть валюту графік \n якої бажаете побачити", font=("Arial", 14), background="darkgray")
label1.pack(side=LEFT, padx=5, pady=5)

frame_general = Frame(root)
btn_general = Button(frame_general, text='General \ngrafic', command=Button_USD, font=("Arial", 10), background="darkgray",width=22)
btn_general.pack(side=LEFT, padx=5, pady=5)

frame2 = Frame(root)
btn2 = Button(frame2, text='USD', command=Button_USD, font=("Arial", 10), background="darkgray",width=22)
btn2.pack(side=LEFT, padx=5, pady=5)

frame3 = Frame(root)
btn3 = Button(frame3, text='EUR', command=Button_EUR, font=("Arial", 10), background="darkgray",width=22)
btn3.pack(side=LEFT, padx=5, pady=5)

frame4 = Frame(root)
btn4 = Button(frame4, text='PLN', command=Button_PLN, font=("Arial", 10), background="darkgray",width=22)
btn4.pack(side=LEFT, padx=5, pady=5)

frame5 = Frame(root)
btn5 = Button(frame5, text='GBP', command=Button_GBP, font=("Arial", 10), background="darkgray",width=22)
btn5.pack(side=LEFT, padx=5, pady=5)

frame6 = Frame(root)
btn6 = Button(frame6, text='CHF', command=Button_CHF, font=("Arial", 10), background="darkgray",width=22)
btn6.pack(side=LEFT, padx=5, pady=5)

frame1.configure(bg="lightgrey")
frame_general.configure(bg="lightgrey")
frame2.configure(bg="lightgrey")
frame3.configure(bg="lightgrey")
frame4.configure(bg="lightgrey")
frame5.configure(bg="lightgrey")
frame6.configure(bg="lightgrey")
frame1.grid(row=0, column=0, sticky=W)
frame_general.grid(row=1, column=0, sticky=W)
frame2.grid(row=2, column=0, sticky=W)
frame3.grid(row=3, column=0, sticky=W)
frame4.grid(row=4, column=0, sticky=W)
frame5.grid(row=5, column=0, sticky=W)
frame6.grid(row=6, column=0, sticky=W)

root.mainloop()
