import pandas
from bs4 import BeautifulSoup
import requests
import re
import csv

#Валюта Покупка Продажа
def add_space_before_caps(string):
    modified_string = re.sub(r'(?<=[a-zа-я])([A-ZА-Я])', r' \1', string)
    return modified_string.strip()

def func_give_header(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, "lxml")
    curses = soup.find_all('div', class_="sc-1x32wa2-0 dWgyGF")
    pars_list = []
    for curs in curses:
        pars_list.append(curs.text.strip())

    result = add_space_before_caps(pars_list[0]) + ';'   
    with open("C:\\Users\\User\\Desktop\\KR Pyton\\MyText.txt", "w", newline='', encoding='cp1251') as f:
        f.write(result.replace(' ', ';'))
        f.write("Дата;\n")


def modify_list(pars_list):
    new_list = []
    for item in pars_list:
        if ',' in item:
            currency, rest = item.split(',', 1)
            if '-' in currency:
                currency = currency.split('-')[0]
            new_list.append(f"{currency},{rest[:2]}")
        else:
            new_list.append(item)
    return new_list
def give_info_for_month(url):
    patern = re.search(r'/(\d{4})-(\d{2})-(\d{2})/', url)
    year = patern.group(1)
    month = patern.group(2)
    day = patern.group(3)
    formatted_date = f"{month}-{year}"
    pars_list = []
    respone = requests.get(url)
    html_content = respone.text
    soup = BeautifulSoup(html_content, features="html.parser")
    tds = soup.tbody.find_all("td")
    for td in tds:
        pars_list.append(td.text.strip())
    pars_list = [text if (i + 1) % 4 != 0 else formatted_date for i, text in enumerate(pars_list)]
    result = modify_list(pars_list)
    #['USD', '38,50', '39,30', '01-03-2023', 'EUR', '40,40', '41,30', '01-03-2023', 'PLN', '8,40', '8,85', '01-03-2023', 'GBP', '44,80', '47,20', '01-03-2023', 'CHF', '39,50', '41,80', '01-03-2023']
    with open("C:\\Users\\User\\Desktop\\KR Pyton\\MyText.txt", "a", encoding='utf-8') as f:
        for i in range(0, len(result), 4):
            f.write(";".join(result[i:i+4]) + ";\n")



url_1 = "https://minfin.com.ua/currency/ukrainka/2020-03-01/"
func_give_header(url_1)
give_info_for_month(url_1)



urls = [
    "https://minfin.com.ua/currency/ukrainka/2020-06-01/",
    "https://minfin.com.ua/currency/ukrainka/2020-09-01/",
    "https://minfin.com.ua/currency/ukrainka/2020-12-01/",
    "https://minfin.com.ua/currency/ukrainka/2021-03-01/",
    "https://minfin.com.ua/currency/ukrainka/2021-09-01/",
    "https://minfin.com.ua/currency/ukrainka/2021-12-01/",
    "https://minfin.com.ua/currency/ukrainka/2022-03-01/",
    "https://minfin.com.ua/currency/ukrainka/2022-06-01/",
    "https://minfin.com.ua/currency/ukrainka/2022-09-01/",
    "https://minfin.com.ua/currency/ukrainka/2021-06-01/",
    "https://minfin.com.ua/currency/ukrainka/2022-12-01/",
    "https://minfin.com.ua/currency/ukrainka/2023-03-01/",
    "https://minfin.com.ua/currency/ukrainka/2023-06-01/",
    "https://minfin.com.ua/currency/ukrainka/2023-09-01/",
    "https://minfin.com.ua/currency/ukrainka/2023-12-01/"
]
for url in urls:
    give_info_for_month(url)
print("Parsing the end")    
#Parsing the end 

# Загальний графік продажі 3м
# Загальний графік купівлі 3м
# середній за рік
# графік купівлі продажу
# 